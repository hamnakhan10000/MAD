import React, { useState, useEffect } from "react";

function App() {
  const [juices, setJuices] = useState([]);
  const [showJuices, setShowJuices] = useState(false);
  const [selectedJuice, setSelectedJuice] = useState(null);
  const [message, setMessage] = useState("");

  // Fetch juices from your MySQL backend
  useEffect(() => {
    fetch("http://localhost:5000/juices")
      .then((res) => res.json())
      .then((data) => setJuices(data))
      .catch((err) => console.error("Error fetching juices:", err));
  }, []);

  // Show juice list
  const handleOrderJuice = () => {
    setShowJuices(true);
    setMessage("");
  };

  // Handle order selection
  const orderJuice = (juice) => {
    setSelectedJuice(juice);
    setShowJuices(false);
    setMessage(`✅ You ordered ${juice.name} ${juice.emoji}`);
  };

  // Handle cancel order
  const cancelOrder = () => {
    setSelectedJuice(null);
    setMessage("❌ Your order has been cancelled.");
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>🍹 Juice Shop</h1>

      {/* Order Juice Button */}
      {!showJuices && !selectedJuice && (
        <button style={styles.button} onClick={handleOrderJuice}>
          🧃 Order Juice
        </button>
      )}

      {/* Juice List */}
      {showJuices && (
        <div style={styles.juiceList}>
          {juices.map((juice) => (
            <button
              key={juice.id}
              style={styles.juiceButton}
              onClick={() => orderJuice(juice)}
            >
              {juice.emoji} {juice.name}
            </button>
          ))}
        </div>
      )}

      {/* Order Summary */}
      {selectedJuice && (
        <div style={styles.orderBox}>
          <p style={styles.message}>{message}</p>
          <button style={styles.cancelButton} onClick={cancelOrder}>
            ❌ Cancel Order
          </button>
        </div>
      )}

      {/* Message after cancel */}
      {!selectedJuice && message && !showJuices && (
        <p style={styles.message}>{message}</p>
      )}
    </div>
  );
}

const styles = {
  container: {
    textAlign: "center",
    minHeight: "100vh",
    background: "linear-gradient(135deg, #f9a8d4, #fef08a, #a7f3d0)",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "Poppins, sans-serif",
    padding: "20px",
  },
  title: {
    fontSize: "40px",
    color: "#333",
    marginBottom: "30px",
  },
  button: {
    backgroundColor: "#10b981",
    color: "white",
    border: "none",
    padding: "15px 30px",
    borderRadius: "25px",
    cursor: "pointer",
    fontSize: "18px",
    fontWeight: "bold",
    transition: "0.3s",
  },
  juiceList: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: "15px",
    marginTop: "20px",
  },
  juiceButton: {
    backgroundColor: "#fff",
    color: "#111",
    border: "2px solid #10b981",
    padding: "12px 20px",
    borderRadius: "15px",
    cursor: "pointer",
    fontSize: "16px",
    fontWeight: "600",
    transition: "0.3s",
  },
  orderBox: {
    marginTop: "30px",
  },
  cancelButton: {
    backgroundColor: "#ef4444",
    color: "white",
    border: "none",
    padding: "10px 20px",
    borderRadius: "10px",
    cursor: "pointer",
    fontSize: "16px",
  },
  message: {
    fontSize: "20px",
    marginTop: "20px",
    color: "#333",
  },
};

export default App;